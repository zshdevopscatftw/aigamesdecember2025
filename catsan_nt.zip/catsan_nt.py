# Catsan NT — Windows NT–style Desktop Shell
import tkinter as tk
import subprocess, sys, time
from pathlib import Path

ROOT = Path(__file__).parent

class CatsanNT(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Catsan NT")
        self.geometry("1024x640")
        self.configure(bg="#008080")

        self.desktop = tk.Frame(self, bg="#008080")
        self.desktop.pack(fill="both", expand=True)

        self._taskbar()
        self._icons()

    def _taskbar(self):
        bar = tk.Frame(self, bg="#202020", height=36)
        bar.pack(side="bottom", fill="x")

        tk.Button(bar, text="Start", command=self.start_menu).pack(side="left", padx=6)
        self.clock = tk.Label(bar, fg="white", bg="#202020")
        self.clock.pack(side="right", padx=10)
        self.tick()

    def tick(self):
        self.clock.config(text=time.strftime("%H:%M:%S"))
        self.after(1000, self.tick)

    def _icons(self):
        tk.Button(
            self.desktop, text="Python",
            command=lambda: subprocess.Popen([sys.executable, str(ROOT / "python.py")])
        ).place(x=40, y=40)

    def start_menu(self):
        win = tk.Toplevel(self)
        win.title("Start")
        win.geometry("200x200")
        tk.Button(win, text="Python", command=lambda: subprocess.Popen([sys.executable, str(ROOT / "python.py")])).pack(fill="x")
        tk.Button(win, text="Exit", command=self.destroy).pack(fill="x")

if __name__ == "__main__":
    CatsanNT().mainloop()
