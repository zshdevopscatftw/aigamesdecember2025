# Catsan NT - Python Interpreter App
import tkinter as tk
from tkinter.scrolledtext import ScrolledText
import code, io, contextlib

class PyConsole(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Catsan Python")
        self.geometry("720x480")

        self.console = code.InteractiveConsole()
        self.output = ScrolledText(self, state="disabled")
        self.output.pack(fill="both", expand=True)

        self.input = tk.Text(self, height=4)
        self.input.pack(fill="x")
        self.input.bind("<Return>", self.run)

        self.write("Catsan NT Python\n>>> ")

    def write(self, text):
        self.output.configure(state="normal")
        self.output.insert("end", text)
        self.output.configure(state="disabled")
        self.output.see("end")

    def run(self, event):
        src = self.input.get("1.0", "end-1c")
        self.input.delete("1.0", "end")

        out, err = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            try:
                self.console.push(src)
            except Exception as e:
                print(e)

        self.write(src + "\n" + out.getvalue() + err.getvalue() + ">>> ")
        return "break"

if __name__ == "__main__":
    PyConsole().mainloop()
