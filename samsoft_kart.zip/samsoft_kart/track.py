import math
from dataclasses import dataclass
import pygame
import numpy as np

@dataclass
class Track:
    size: int
    surface: pygame.Surface          # RGB texture for sampling
    road_mask: np.ndarray            # bool array [w,h] where True = road
    boost_mask: np.ndarray           # bool array [w,h] where True = boost pad
    minimap: pygame.Surface          # tiny preview

    def is_road(self, x: float, y: float) -> bool:
        ix = int(x) % self.size
        iy = int(y) % self.size
        return bool(self.road_mask[ix, iy])

    def is_boost(self, x: float, y: float) -> bool:
        ix = int(x) % self.size
        iy = int(y) % self.size
        return bool(self.boost_mask[ix, iy])


def _make_checker_grass(size: int) -> pygame.Surface:
    surf = pygame.Surface((size, size))
    # simple 16px checker to give motion cues
    tile = 16
    c1 = (55, 140, 70)
    c2 = (50, 130, 65)
    for y in range(0, size, tile):
        for x in range(0, size, tile):
            surf.fill(c1 if ((x//tile + y//tile) % 2 == 0) else c2, (x, y, tile, tile))
    return surf


def generate_track(size: int = 512) -> Track:
    """
    Generates an original 'oval ring' circuit texture and masks:
    - road_mask: where the kart gets full grip / speed
    - boost_mask: small pads that add acceleration
    """
    tex = _make_checker_grass(size)

    # Road: ring made by drawing a big filled ellipse, then punching out inner ellipse.
    road_color = (70, 75, 80)
    kerb_color = (225, 60, 60)
    line_color = (230, 230, 230)

    center = (size // 2, size // 2)
    rx, ry = int(size * 0.34), int(size * 0.26)
    road_half_width = int(size * 0.06)

    # Road layer
    road_layer = pygame.Surface((size, size), flags=pygame.SRCALPHA)
    outer_rect = pygame.Rect(0, 0, (rx + road_half_width) * 2, (ry + road_half_width) * 2)
    outer_rect.center = center
    inner_rect = pygame.Rect(0, 0, (rx - road_half_width) * 2, (ry - road_half_width) * 2)
    inner_rect.center = center

    pygame.draw.ellipse(road_layer, road_color, outer_rect)
    pygame.draw.ellipse(road_layer, (0, 0, 0, 0), inner_rect)

    # Kerbs (red/white stripes) along outer edge
    # We'll draw short arc segments by plotting points on the ellipse.
    kerb = pygame.Surface((size, size), flags=pygame.SRCALPHA)
    num_seg = 64
    for i in range(num_seg):
        t0 = (i / num_seg) * math.tau
        t1 = ((i + 1) / num_seg) * math.tau
        if i % 2 == 0:
            # sample a polyline segment on outer ellipse
            pts = []
            for j in range(5):
                t = t0 + (t1 - t0) * (j / 4)
                x = center[0] + (rx + road_half_width) * math.cos(t)
                y = center[1] + (ry + road_half_width) * math.sin(t)
                pts.append((x, y))
            pygame.draw.lines(kerb, kerb_color, False, pts, 6)

    # Lane line (dashed) along midline
    mid_rx, mid_ry = rx, ry
    for i in range(0, 96, 2):
        t0 = (i / 96) * math.tau
        t1 = ((i + 1) / 96) * math.tau
        pts = []
        for j in range(4):
            t = t0 + (t1 - t0) * (j / 3)
            x = center[0] + mid_rx * math.cos(t)
            y = center[1] + mid_ry * math.sin(t)
            pts.append((x, y))
        pygame.draw.lines(road_layer, line_color, False, pts, 2)

    # Composite layers onto texture
    tex.blit(road_layer, (0, 0))
    tex.blit(kerb, (0, 0))

    # Start/finish stripe for vibes (visual only)
    start = pygame.Surface((size, size), flags=pygame.SRCALPHA)
    sx = center[0] + rx
    sy = center[1]
    pygame.draw.rect(start, (240, 240, 240), pygame.Rect(sx - 6, sy - 36, 12, 72))
    for k in range(7):
        if k % 2 == 0:
            pygame.draw.rect(start, (30, 30, 30), pygame.Rect(sx - 6, sy - 36 + k * 10, 12, 10))
    tex.blit(start, (0, 0))

    # Boost pads
    boost_layer = pygame.Surface((size, size), flags=pygame.SRCALPHA)
    boost_color = (90, 200, 255)
    pad_w, pad_h = 26, 10
    # place a few pads along the ring
    for t in (0.25 * math.tau, 0.62 * math.tau, 0.87 * math.tau):
        px = center[0] + rx * math.cos(t)
        py = center[1] + ry * math.sin(t)
        # orient pad roughly along tangent: rotate a small surface then blit
        angle = math.degrees(t + math.pi / 2)
        pad = pygame.Surface((pad_w, pad_h), flags=pygame.SRCALPHA)
        pad.fill((0, 0, 0, 0))
        pygame.draw.rect(pad, boost_color, pygame.Rect(0, 0, pad_w, pad_h), border_radius=2)
        pygame.draw.rect(pad, (255, 255, 255), pygame.Rect(3, 3, pad_w - 6, pad_h - 6), 1, border_radius=2)
        pad_rot = pygame.transform.rotate(pad, -angle)
        rect = pad_rot.get_rect(center=(px, py))
        boost_layer.blit(pad_rot, rect.topleft)
    tex.blit(boost_layer, (0, 0))

    # Build masks using surfarray for speed
    tex_rgb = pygame.surfarray.array3d(tex)  # [w,h,3]
    # Road is where the pixel is close to road_color (within a tolerance).
    road = tex_rgb[:, :, 0].astype(np.int16)
    g = tex_rgb[:, :, 1].astype(np.int16)
    b = tex_rgb[:, :, 2].astype(np.int16)
    road_mask = (abs(road - road_color[0]) < 25) & (abs(g - road_color[1]) < 25) & (abs(b - road_color[2]) < 25)

    # Boost mask: detect boost_color-ish
    boost_mask = (abs(road - boost_color[0]) < 25) & (abs(g - boost_color[1]) < 25) & (abs(b - boost_color[2]) < 25)

    # Minimap
    minimap = pygame.transform.smoothscale(tex, (64, 64))

    return Track(
        size=size,
        surface=tex.convert(),
        road_mask=road_mask,
        boost_mask=boost_mask,
        minimap=minimap.convert(),
    )
