# Samsoft Kart (PyGame)

A tiny, original-asset kart racer **demo** with a DS-ish internal resolution (256×192) and a Mode7-like ground renderer.

This is **not** Mario Kart and it doesn't use Nintendo branding/assets — it's an original mini project with similar vibes.

## Requirements
- Python 3.10+
- pygame
- numpy (used for fast ground rendering)

Install:
```bash
pip install pygame numpy
```

## Run
```bash
python main.py
```

## Controls
- Arrow keys: steer / accelerate / brake
- Space: drift (stronger turning + sparks)
- R: reset
- F1: toggle FPS counter
- Esc: quit

## Notes
- The world wraps around the track texture (so you can drive forever).
- Boost pads (blue) add extra acceleration.
