# Samsoft Kart — settings
# Internal render resolution is DS-ish (256x192) for speed.
INTERNAL_W = 256
INTERNAL_H = 192
SCALE = 4  # window upscale (integer recommended)

WINDOW_W = INTERNAL_W * SCALE
WINDOW_H = INTERNAL_H * SCALE

FPS = 60

TRACK_SIZE = 512  # texture size (world wraps)
HORIZON_Y = 78    # where the ground starts (0..INTERNAL_H-1)

# "Mode7" projection tuning
CAM_HEIGHT = 60.0
FOV_DEG = 70.0

# Kart physics
MAX_SPEED_ROAD = 240.0      # world units / second
MAX_SPEED_OFFROAD = 150.0
ACCEL = 220.0               # units / s^2
BRAKE = 260.0
FRICTION = 140.0
OFFROAD_FRICTION = 220.0
REVERSE_MAX = 110.0

STEER_RATE = 2.4            # radians/s at full steer, scaled by speed
STEER_RATE_DRIFT = 3.2

BOOST_STRENGTH = 340.0      # extra accel on boost pad
