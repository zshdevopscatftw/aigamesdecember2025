import math
import pygame
import numpy as np

class Mode7Renderer:
    """
    Fast-ish Mode7-like ground renderer using numpy + pygame.surfarray.

    World coordinates map directly into the track texture pixels.
    """
    def __init__(
        self,
        texture: pygame.Surface,
        *,
        horizon_y: int,
        cam_height: float,
        fov_deg: float,
        screen_w: int,
        screen_h: int,
    ) -> None:
        self.texture = texture
        self.horizon_y = horizon_y
        self.cam_height = float(cam_height)
        self.screen_w = int(screen_w)
        self.screen_h = int(screen_h)

        self.tex_array = pygame.surfarray.array3d(texture)  # [tw,th,3]
        self.tw, self.th = self.tex_array.shape[0], self.tex_array.shape[1]

        self.x_lerp = np.linspace(0.0, 1.0, self.screen_w, endpoint=False, dtype=np.float32)

        # Projection tuning constant. Bigger => "flatter" + more visible distance.
        self.proj = 120.0

        self.fov_scale = float(math.tan(math.radians(fov_deg) / 2.0))

        # Precompute sky gradient rows [horizon,3]
        top = np.array([120, 185, 255], dtype=np.float32)
        bot = np.array([180, 225, 255], dtype=np.float32)
        if self.horizon_y <= 1:
            self.sky_rows = np.tile(bot.astype(np.uint8), (max(self.horizon_y, 1), 1))
        else:
            t = np.linspace(0.0, 1.0, self.horizon_y, dtype=np.float32)[:, None]
            self.sky_rows = (top * (1.0 - t) + bot * t).astype(np.uint8)

    def render_ground(self, target: pygame.Surface, cam_x: float, cam_y: float, cam_angle: float) -> None:
        W, H = self.screen_w, self.screen_h
        h0 = self.horizon_y
        cos_a = math.cos(cam_angle)
        sin_a = math.sin(cam_angle)
        dir_x, dir_y = cos_a, sin_a
        right_x, right_y = -sin_a, cos_a

        arr = pygame.surfarray.pixels3d(target)  # view, locks surface

        # Sky
        if h0 > 0:
            arr[:, :h0, :] = self.sky_rows[None, :, :]

        # Ground scanlines
        for y in range(h0, H):
            p = (y - h0) + 1.0  # avoid div0
            row_dist = (self.cam_height * self.proj) / p

            half_width = row_dist * self.fov_scale
            # Row endpoints in world space
            start_x = cam_x + dir_x * row_dist - right_x * half_width
            start_y = cam_y + dir_y * row_dist - right_y * half_width
            end_x   = cam_x + dir_x * row_dist + right_x * half_width
            end_y   = cam_y + dir_y * row_dist + right_y * half_width

            wx = start_x + (end_x - start_x) * self.x_lerp
            wy = start_y + (end_y - start_y) * self.x_lerp

            ix = (wx.astype(np.int32) % self.tw)
            iy = (wy.astype(np.int32) % self.th)

            arr[:, y, :] = self.tex_array[ix, iy, :]

        # Unlock surface
        del arr

    def project_point(self, world_x: float, world_y: float, cam_x: float, cam_y: float, cam_angle: float):
        """
        Project a point on the ground plane into screen space.

        Returns (sx, sy, scale, forward) or None if behind the camera or off-screen.
        """
        dx = world_x - cam_x
        dy = world_y - cam_y
        cos_a = math.cos(cam_angle)
        sin_a = math.sin(cam_angle)
        dir_x, dir_y = cos_a, sin_a
        right_x, right_y = -sin_a, cos_a

        forward = dx * dir_x + dy * dir_y
        if forward <= 1.0:
            return None

        side = dx * right_x + dy * right_y

        # Screen y from inverse of row_dist formula:
        p = (self.cam_height * self.proj) / forward
        sy = self.horizon_y + p

        if sy < self.horizon_y or sy >= self.screen_h + 20:
            return None

        # Screen x based on FOV:
        half_width = forward * self.fov_scale
        nx = side / half_width  # -1..1 approx
        sx = (0.5 + 0.5 * nx) * self.screen_w

        if sx < -40 or sx > self.screen_w + 40:
            return None

        # Sprite scale: closer => bigger
        scale = max(0.05, min(2.2, 120.0 / forward))
        return float(sx), float(sy), float(scale), float(forward)
