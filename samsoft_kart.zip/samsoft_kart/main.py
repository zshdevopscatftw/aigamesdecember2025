import math
import random
import pygame

from settings import (
    INTERNAL_W, INTERNAL_H, WINDOW_W, WINDOW_H, SCALE, FPS,
    TRACK_SIZE, HORIZON_Y, CAM_HEIGHT, FOV_DEG,
    MAX_SPEED_ROAD, MAX_SPEED_OFFROAD, ACCEL, BRAKE, FRICTION, OFFROAD_FRICTION,
    REVERSE_MAX, STEER_RATE, STEER_RATE_DRIFT, BOOST_STRENGTH,
)
from track import generate_track
from mode7 import Mode7Renderer
from kart import Kart


def make_kart_sprite(size=(24, 14), color=(255, 220, 90), outline=(20, 20, 20)) -> pygame.Surface:
    w, h = size
    surf = pygame.Surface((w, h), pygame.SRCALPHA)
    pygame.draw.polygon(
        surf,
        color,
        [(0, h-1), (3, 2), (w-4, 2), (w-1, h-1), (w-6, h-4), (5, h-4)],
    )
    pygame.draw.polygon(
        surf,
        outline,
        [(0, h-1), (3, 2), (w-4, 2), (w-1, h-1), (w-6, h-4), (5, h-4)],
        2,
    )
    # little "visor"
    pygame.draw.rect(surf, (255, 255, 255, 180), pygame.Rect(8, 4, w-16, 4), border_radius=2)
    return surf


class Intro:
    def __init__(self, screen_w: int, screen_h: int) -> None:
        self.w = screen_w
        self.h = screen_h
        self.t = 0.0
        self.done = False
        self.font_big = pygame.font.Font(None, 34)
        self.font_small = pygame.font.Font(None, 18)

    def update(self, dt: float) -> None:
        self.t += dt
        if self.t >= 2.8:
            self.done = True

    def draw(self, surf: pygame.Surface) -> None:
        surf.fill((0, 0, 0))
        # fade in/out
        alpha = 1.0
        if self.t < 0.6:
            alpha = self.t / 0.6
        elif self.t > 2.2:
            alpha = max(0.0, 1.0 - (self.t - 2.2) / 0.6)
        a = int(255 * max(0.0, min(1.0, alpha)))

        title = self.font_big.render("SAMSOFT PRESENTS", True, (255, 255, 255))
        sub = self.font_small.render("PyKart DS-style demo (original assets)", True, (200, 200, 200))

        title.set_alpha(a)
        sub.set_alpha(a)

        surf.blit(title, title.get_rect(center=(self.w // 2, self.h // 2 - 8)))
        surf.blit(sub, sub.get_rect(center=(self.w // 2, self.h // 2 + 18)))


def main() -> None:
    pygame.init()
    pygame.display.set_caption("Samsoft Kart — PyGame DS-style demo")
    window = pygame.display.set_mode((WINDOW_W, WINDOW_H))
    clock = pygame.time.Clock()

    # Internal render target (DS-ish), scaled up to window
    frame = pygame.Surface((INTERNAL_W, INTERNAL_H)).convert()

    # Generate track + renderer
    track = generate_track(TRACK_SIZE)
    renderer = Mode7Renderer(
        track.surface,
        horizon_y=HORIZON_Y,
        cam_height=CAM_HEIGHT,
        fov_deg=FOV_DEG,
        screen_w=INTERNAL_W,
        screen_h=INTERNAL_H,
    )

    # Player kart start near the start/finish line on the right side of the oval
    cx = TRACK_SIZE / 2
    cy = TRACK_SIZE / 2
    start_x = cx + TRACK_SIZE * 0.34
    start_y = cy
    player = Kart(x=start_x, y=start_y, angle=math.pi)  # facing left

    # Simple AI karts orbit the oval
    ai_sprites = [
        make_kart_sprite((22, 12), (120, 255, 170)),
        make_kart_sprite((22, 12), (160, 210, 255)),
        make_kart_sprite((22, 12), (255, 160, 210)),
    ]
    ai = []
    for i in range(3):
        ai.append({
            "t": random.random() * math.tau,
            "speed": 0.45 + 0.08 * i,  # radians/sec
            "sprite": ai_sprites[i],
        })

    # UI
    font = pygame.font.Font(None, 20)
    font_small = pygame.font.Font(None, 16)

    # Intro
    intro = Intro(INTERNAL_W, INTERNAL_H)

    # fixed player sprite (third-person)
    player_sprite = make_kart_sprite((28, 16), (255, 220, 90))
    drifting = False
    drift_sparks_t = 0.0

    running = True
    show_fps = True

    while running:
        dt = clock.tick(FPS) / 1000.0

        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                running = False
            elif e.type == pygame.KEYDOWN:
                if e.key == pygame.K_ESCAPE:
                    running = False
                if e.key == pygame.K_F1:
                    show_fps = not show_fps
                if e.key == pygame.K_r:
                    player.x, player.y, player.angle, player.speed = start_x, start_y, math.pi, 0.0

        keys = pygame.key.get_pressed()

        # Intro sequence
        if not intro.done:
            intro.update(dt)
            intro.draw(frame)
        else:
            # Inputs
            throttle = 1.0 if keys[pygame.K_UP] else 0.0
            brake = 1.0 if keys[pygame.K_DOWN] else 0.0
            steer = (1.0 if keys[pygame.K_RIGHT] else 0.0) - (1.0 if keys[pygame.K_LEFT] else 0.0)
            drifting = keys[pygame.K_SPACE]

            on_road = track.is_road(player.x, player.y)
            on_boost = track.is_boost(player.x, player.y)

            player.update(
                dt,
                throttle=throttle,
                brake=brake,
                steer=steer,
                drifting=drifting,
                on_road=on_road,
                on_boost=on_boost,
                max_speed_road=MAX_SPEED_ROAD,
                max_speed_offroad=MAX_SPEED_OFFROAD,
                accel=ACCEL,
                brake_strength=BRAKE,
                friction=FRICTION,
                offroad_friction=OFFROAD_FRICTION,
                reverse_max=REVERSE_MAX,
                steer_rate=STEER_RATE,
                steer_rate_drift=STEER_RATE_DRIFT,
                boost_strength=BOOST_STRENGTH,
            )

            # Update AI orbiting the oval midline
            rx = TRACK_SIZE * 0.34
            ry = TRACK_SIZE * 0.26
            for bot in ai:
                bot["t"] = (bot["t"] + bot["speed"] * dt) % math.tau
                bot["x"] = cx + rx * math.cos(bot["t"])
                bot["y"] = cy + ry * math.sin(bot["t"])

            # Camera behind player
            cam_back = 56.0
            cam_x = player.x - math.cos(player.angle) * cam_back
            cam_y = player.y - math.sin(player.angle) * cam_back
            cam_angle = player.angle

            # Ground
            renderer.render_ground(frame, cam_x, cam_y, cam_angle)

            # Project + draw AI karts (billboards)
            projected = []
            for bot in ai:
                pr = renderer.project_point(bot["x"], bot["y"], cam_x, cam_y, cam_angle)
                if pr:
                    sx, sy, sc, fwd = pr
                    projected.append((fwd, sx, sy, sc, bot["sprite"]))
            projected.sort(reverse=True)  # far -> near

            for fwd, sx, sy, sc, spr in projected:
                w = max(2, int(spr.get_width() * sc))
                h = max(2, int(spr.get_height() * sc))
                spr2 = pygame.transform.smoothscale(spr, (w, h))
                rect = spr2.get_rect(center=(int(sx), int(sy) - int(h * 0.35)))
                frame.blit(spr2, rect.topleft)

            # Player kart sprite at fixed spot (third-person)
            px = INTERNAL_W // 2
            py = INTERNAL_H - 28
            frame.blit(player_sprite, player_sprite.get_rect(center=(px, py)))

            # Drift sparks (cosmetic)
            if drifting and abs(steer) > 0.1 and abs(player.speed) > 90:
                drift_sparks_t += dt
                if drift_sparks_t > 0.03:
                    drift_sparks_t = 0.0
                    for side in (-1, 1):
                        sx = px + side * 12 + random.randint(-1, 1)
                        sy = py + 8 + random.randint(-1, 1)
                        pygame.draw.circle(frame, (255, 240, 160), (sx, sy), 1)
            else:
                drift_sparks_t = 0.0

            # HUD
            speed_kmh = max(0.0, player.speed) * 0.18  # not real km/h; just a fun number
            hud = font.render(f"Speed {speed_kmh:05.1f}  |  {'ROAD' if on_road else 'OFFROAD'}", True, (20, 20, 20))
            frame.blit(hud, (8, 8))

            # Minimap
            frame.blit(track.minimap, (INTERNAL_W - 72, 8))
            mx, my = INTERNAL_W - 72, 8
            dot_x = int(mx + (player.x % TRACK_SIZE) / TRACK_SIZE * 64)
            dot_y = int(my + (player.y % TRACK_SIZE) / TRACK_SIZE * 64)
            pygame.draw.circle(frame, (255, 60, 60), (dot_x, dot_y), 2)

            help1 = font_small.render("Arrows: drive  |  Space: drift  |  R: reset  |  F1: FPS", True, (20, 20, 20))
            frame.blit(help1, (8, INTERNAL_H - 16))

            if show_fps:
                fps_txt = font_small.render(f"{clock.get_fps():.1f} FPS", True, (20, 20, 20))
                frame.blit(fps_txt, (INTERNAL_W - 60, INTERNAL_H - 16))

        # Scale internal frame to window
        if SCALE == 1:
            window.blit(frame, (0, 0))
        else:
            window.blit(pygame.transform.scale(frame, (WINDOW_W, WINDOW_H)), (0, 0))
        pygame.display.flip()

    pygame.quit()


if __name__ == "__main__":
    main()
