import math
from dataclasses import dataclass

def _approach(value: float, target: float, delta: float) -> float:
    if value < target:
        return min(value + delta, target)
    return max(value - delta, target)

@dataclass
class Kart:
    x: float
    y: float
    angle: float  # radians
    speed: float = 0.0

    def update(
        self,
        dt: float,
        throttle: float,
        brake: float,
        steer: float,
        drifting: bool,
        on_road: bool,
        on_boost: bool,
        *,
        max_speed_road: float,
        max_speed_offroad: float,
        accel: float,
        brake_strength: float,
        friction: float,
        offroad_friction: float,
        reverse_max: float,
        steer_rate: float,
        steer_rate_drift: float,
        boost_strength: float,
    ) -> None:
        # Limits and grip
        max_fwd = max_speed_road if on_road else max_speed_offroad
        fr = friction if on_road else offroad_friction

        # Accel / brake
        if throttle > 0.0:
            self.speed += accel * throttle * dt
        if brake > 0.0:
            if self.speed > 0:
                self.speed -= brake_strength * brake * dt
            else:
                # reverse
                self.speed -= (accel * 0.65) * brake * dt

        # Boost pad gives a shove forward, even if you're coasting
        if on_boost and self.speed >= 0:
            self.speed += boost_strength * dt

        # Clamp
        if self.speed >= 0:
            self.speed = min(self.speed, max_fwd)
        else:
            self.speed = max(self.speed, -reverse_max)

        # Friction (coast toward 0)
        self.speed = _approach(self.speed, 0.0, fr * dt)

        # Steering: stronger at speed, weaker when stopped/reversing
        speed_factor = min(abs(self.speed) / max_speed_road, 1.0)
        turn = (steer_rate_drift if drifting else steer_rate) * speed_factor
        self.angle += steer * turn * dt * (1 if self.speed >= 0 else -1)

        # Integrate position
        dx = math.cos(self.angle) * self.speed * dt
        dy = math.sin(self.angle) * self.speed * dt
        self.x += dx
        self.y += dy
